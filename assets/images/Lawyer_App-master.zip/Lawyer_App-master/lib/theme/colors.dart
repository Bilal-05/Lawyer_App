import 'package:flutter/material.dart';

class AppColors {
  static Color primaryColor = const Color(0xff213442);
  static Color greyShade = const Color(0xff626262);
}
